package com.example.book_review.data.local;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import java.util.List;

@Dao
public interface BookDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(BookEntity book);

    @Query("SELECT * FROM favorite_books")
    LiveData<List<BookEntity>> getAllFavorites();

    @Delete
    void delete(BookEntity book);
}