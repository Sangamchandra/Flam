package com.example.book_review.ui.bookdetail;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.book_review.R;
import com.example.book_review.data.local.AppDatabase;
import com.example.book_review.data.local.BookEntity;
import com.example.book_review.domain.model.Book;
import com.squareup.picasso.Picasso;

public class BookDetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        Book book = (Book) getIntent().getSerializableExtra("book");

        TextView title = findViewById(R.id.title);
        TextView author = findViewById(R.id.author);
        TextView desc = findViewById(R.id.description);
        TextView rating = findViewById(R.id.rating);
        ImageView img = findViewById(R.id.thumbnail);
        Button fav = findViewById(R.id.btnFavorite);

        title.setText(book.getTitle());
        author.setText(book.getAuthor());
        desc.setText(book.getDescription());
        rating.setText("Rating: " + book.getRating());
        // Simulate image loading
        img.setImageResource(R.drawable.ic_book_placeholder);

        fav.setOnClickListener(v -> {
            BookEntity e = new BookEntity();
            e.id = book.getId();
            e.title = book.getTitle();
            e.author = book.getAuthor();
            e.description = book.getDescription();
            e.rating = book.getRating();
            e.thumbnail = book.getThumbnail();
            AppDatabase.getInstance(this).bookDao().insert(e);
        });
    }
}
