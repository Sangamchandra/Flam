package com.example.book_review.utils;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.example.book_review.data.repository.BookRepository;
import com.example.book_review.ui.booklist.BookListViewModel;

public class BookListViewModelFactory implements ViewModelProvider.Factory {
    private final BookRepository repository;

    public BookListViewModelFactory(BookRepository repo) {
        repository = repo;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass.isAssignableFrom(BookListViewModel.class)) {
            return (T) new BookListViewModel(repository);
        }
        throw new IllegalArgumentException("Unknown ViewModel class");
    }
}