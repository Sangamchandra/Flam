package com.example.book_review.data.repository;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.example.book_review.data.local.BookDao;
import com.example.book_review.data.local.BookEntity;
import com.example.book_review.data.remote.BookApiService;
import com.example.book_review.data.remote.RetrofitClient;
import com.example.book_review.domain.model.Book;
import java.util.List;
import java.util.concurrent.Executors;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BookRepository {
    private BookApiService apiService;
    private BookDao bookDao;

    public BookRepository(BookDao dao) {
        apiService = RetrofitClient.getInstance();
        bookDao = dao;
    }

    public LiveData<List<Book>> getBooksFromApi() {
        MutableLiveData<List<Book>> booksLiveData = new MutableLiveData<>();
        apiService.getBooks().enqueue(new Callback<List<Book>>() {
            @Override
            public void onResponse(Call<List<Book>> call, Response<List<Book>> response) {
                booksLiveData.setValue(response.body());
            }
            @Override
            public void onFailure(Call<List<Book>> call, Throwable t) {
                booksLiveData.setValue(null);
            }
        });
        return booksLiveData;
    }

    public LiveData<List<BookEntity>> getFavorites() {
        return bookDao.getAllFavorites();
    }

    public void saveFavorite(BookEntity book) {
        Executors.newSingleThreadExecutor().execute(() -> bookDao.insert(book));
    }

    public void deleteFavorite(BookEntity book) {
        Executors.newSingleThreadExecutor().execute(() -> bookDao.delete(book));
    }
}
