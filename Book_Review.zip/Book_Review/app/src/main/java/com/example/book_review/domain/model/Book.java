package com.example.book_review.domain.model;

import java.io.Serializable;
public class Book implements Serializable {
    private int id;
    private String title;
    private String author;
    private String description;
    private String thumbnail;
    private float rating;

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getDescription() { return description; }
    public String getThumbnail() { return thumbnail; }
    public float getRating() { return rating; }
}