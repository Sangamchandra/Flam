package com.example.book_review.ui.booklist;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import com.example.book_review.data.local.BookEntity;
import com.example.book_review.data.repository.BookRepository;
import com.example.book_review.domain.model.Book;
import java.util.List;

public class BookListViewModel extends ViewModel {
    private BookRepository repository;
    private LiveData<List<Book>> books;
    private LiveData<List<BookEntity>> favorites;

    public BookListViewModel(BookRepository repo) {
        repository = repo;
        books = repository.getBooksFromApi();
        favorites = repository.getFavorites();
    }

    public LiveData<List<Book>> getBooks() { return books; }
    public LiveData<List<BookEntity>> getFavorites() { return favorites; }
    public void saveFavorite(BookEntity book) { repository.saveFavorite(book); }
    public void deleteFavorite(BookEntity book) { repository.deleteFavorite(book); }
}
