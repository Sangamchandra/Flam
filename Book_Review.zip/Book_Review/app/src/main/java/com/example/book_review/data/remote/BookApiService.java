package com.example.book_review.data.remote;

import com.example.book_review.domain.model.Book;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;

public interface BookApiService {
    @GET("books.json")
    Call<List<Book>> getBooks();
}