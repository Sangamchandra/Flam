package com.example.book_review.ui.booklist;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.book_review.R;
import com.example.book_review.data.local.AppDatabase;
import com.example.book_review.data.repository.BookRepository;
import com.example.book_review.domain.model.Book;
import com.example.book_review.ui.bookdetail.BookDetailActivity;
import com.example.book_review.utils.BookListViewModelFactory;

import java.util.ArrayList;
import java.util.List;

public class BookListActivity extends AppCompatActivity implements BookListAdapter.OnItemClickListener {
    private BookListViewModel viewModel;
    private BookListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_list);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<Book> bookList = new ArrayList<>();
        adapter = new BookListAdapter(bookList, this);
        recyclerView.setAdapter(adapter);

        BookRepository repository = new BookRepository(AppDatabase.getInstance(this).bookDao());
        viewModel = new ViewModelProvider(this, new BookListViewModelFactory(repository)).get(BookListViewModel.class);

        viewModel.getBooks().observe(this, adapter::setBooks);
    }

    @Override
    public void onItemClick(Book book) {
        Intent intent = new Intent(this, BookDetailActivity.class);
        intent.putExtra("book", book);
        startActivity(intent);
    }
}
