package com.example.book_review.data.local;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "favorite_books")
public class BookEntity {
    @PrimaryKey
    public int id;
    public String title;
    public String author;
    public String description;
    public String thumbnail;
    public float rating;
}